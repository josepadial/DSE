# MPU6050-PSoc5

Modelo empírico de la planta con arduino:

Recolección de medicones para el modelo teórico de 
un robot tipo sewgay, utilizando un MPU6050 y un 
estímulo rectangular de ancho variable.

Requiere un pushbutton con un pull-up de 10k ohms
a VCC, timePulse es el tiempo en que el escalón 
está en alto. 

Las mediciones finalizan al oprimir
el botón de reset, luego se debe posicionar en el 
monitor serial pulsar CTRL+A, CTRL+C, crear un 
documento de texto y pegar los datos del monitor 
serial con CTRL+V, luego guardar este documento con 
la extensión .csv, abrir excel y exportar el documento
csv creado, listo para ser editado.
