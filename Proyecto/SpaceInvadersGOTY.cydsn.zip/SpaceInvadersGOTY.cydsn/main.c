#include <project.h>
#include <mpu6050.h>
#include <stdio.h>
#include <math.h>
#include<stdlib.h> 

uint16 ADCResult;
int16_t CAX, CAY, CAZ; //current acceleration values
int16_t CGX, CGY, CGZ; //current gyroscope values
int16_t CT;            //current temperature
int h=0,i=0,dato=0;

int vel_bala=0;
int balas_activas = 0;

int jugador=0;
int col=0;

int puntuacion=0;
int muerto = 0;
int reset = 0;


void imprimirJugador(){
    StripLights_Pixel(jugador,col,StripLights_LTBLUE);
}

typedef struct monstruo monstruo;
struct monstruo{
  int posx;
  int posy;
  int tipo;
  int velocidad;
  int muerto;
  int contador;
  uint32 color;
  
};

typedef struct structbalas structbalas;
struct structbalas{
  int posx;
  int posy;
  int disparada;
};

structbalas balas[16]; 

void movimiento(monstruo *m){
    
    if(m->contador>=m->velocidad){
        m->posy--;
        if(m->posy==1){
            m->posy=15;
            m->tipo=(rand()%3)+1;
            m->muerto=0;   
        }
        int dir = rand()%3;
       
        
        switch (dir){
            case 0:
                if((m->posx%4)==0){
                    m->posx++;
                }
                else if(m->tipo==1 && m->posx%4==1)
                    m->posx++;
                else
                    m->posx--;
                break;
            
            case 2:
                if(m->posx%4==3){
                    m->posx--;
                }
                else
                    m->posx++;
                break;
        }
        
        m->contador=0;
    }
    else{
        m->contador++;
    }
}

void imprimirMonstruo(monstruo m){
    if(m.muerto == 0){
        if(m.tipo == 1 || m.tipo==2)
           StripLights_Pixel(m.posx,m.posy-1,m.color);
        if(m.tipo == 1){
            StripLights_Pixel(m.posx-1,m.posy-1,m.color);
            StripLights_Pixel(m.posx-1,m.posy,m.color);
        }   
        
        StripLights_Pixel(m.posx,m.posy,m.color);   
    }

}

void imprimirBalas(){
    int j=0;
    for(int i=0; i<16; i++){
        if(balas[i].disparada==1 && balas[i].posy<15)
            StripLights_Pixel(balas[i].posx,balas[i].posy,StripLights_LTGREEN); 
        else if(balas[i].posy==0){
            StripLights_Pixel(j,0,StripLights_LTGREEN);
            j++;
        }
    }
}

int detectarColision(int x, int y, monstruo m){
    if(m.muerto == 0){
        if(m.tipo == 1){
            if(x == m.posx || x == m.posx -1){
                if(y == m.posy || y == m.posy -1){
                    return 1;
                }
            }
            return 0;
        }
        if(m.tipo == 2){
            if(x == m.posx){
                if(y == m.posy || y == m.posy -1){
                    return 1;
                }
            }
            return 0;
        }
        else{
            if(x == m.posx){
                if(y == m.posy)
                    return 1;
            }
            return 0;
        }
    }
    else 
        return 0;
}

void moverBalas(){
    for(int i=0; i<16; i++){
        if(balas[i].disparada==1){
            if(balas[i].posy > 93){
                balas[i].disparada=0; 
                balas[i].posy=0;
                balas_activas--;
            }
            else{
                balas[i].posy++; 
            }

        }
    }
}

int main()
{
	uint8_t canal = 0;
    int32 adcread;
    float voltaje;
	int j = 0; //for loop increment variable
    char buf[50]; //just to hold text values in for writing to LCD
    
    
    monstruo monstruo1;
    monstruo1.tipo=0;
    monstruo1.posx=0;
    monstruo1.posy=15;
    monstruo1.velocidad=3;
    monstruo1.muerto=0;
    monstruo1.contador=0;
    monstruo1.color=0x009933;
    
    monstruo monstruo2;
    monstruo2.tipo=1;
    monstruo2.posx=4;
    monstruo2.posy=15;
    monstruo2.velocidad=5;
    monstruo2.muerto=0;
    monstruo2.contador=0;
    monstruo2.color=StripLights_LTYELLOW;
    
    monstruo monstruo3;
    monstruo3.tipo=2;
    monstruo3.posx=8;
    monstruo3.velocidad=4;
    monstruo3.contador=0;
    monstruo3.muerto=0;
    monstruo3.posy=15;
    
    monstruo3.color=StripLights_LTRED;
    
    monstruo monstruo4;
    monstruo4.tipo=0;
    monstruo4.posx=12;
    monstruo4.posy=15;
    monstruo4.velocidad=3;
    monstruo4.contador=0;
    monstruo4.muerto=0;
    monstruo4.color=0x221111;
    
    
	I2C_MPU6050_Start();

    CyGlobalIntEnable;
    
    StripLights_Start();
    StripLights_DisplayClear(StripLights_BLACK);
    
    MUX_Start();

	MPU6050_init();
	MPU6050_initialize();
    
    LCD_Start();
    LCD_ClearDisplay();
    ADC_Start();
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    
    PWM_Init();

    LCD_Position(0,0);
    float accel_ang_x;
    float accel_ang_y;
    LCD_Position(0,0);
    sprintf(buf, "Calibrando:");
    LCD_PrintString(buf);
    LCD_Position(1,2);
    LCD_PrintString("Espere...");
    
    for(int i=0; i<16; i++){
        balas[i].posx=0;  
        balas[i].posy=0;
        balas[i].disparada=0;
    }
 
    
    for(j=0; j<100; j++)
    {
        MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ, &CT);
        
        accel_ang_x=atan(CAX/sqrt(pow(CAY,2) + pow(CAZ,2)))*(180.0/3.14);
        accel_ang_y=atan(CAY/sqrt(pow(CAX,2) + pow(CAZ,2)))*(180.0/3.14);

        LCD_Position(0,12);
        sprintf(buf, "%d%c",j,'%');
        LCD_PrintString(buf);

        CyDelay(50);
    }  

    LCD_ClearDisplay();

    for (;;){
        
        MUX_FastSelect(canal);
        adcread=ADC_GetResult32();
        voltaje=floor(((5.000/1048576)*adcread));
        MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ, &CT);
    
        accel_ang_x=ceil(atan(CAX/sqrt(pow(CAY,2) + pow(CAZ,2)))*(180.0/3.14));
        accel_ang_y=ceil(atan(CAY/sqrt(pow(CAX,2) + pow(CAZ,2)))*(180.0/3.14));
        
        /*LCD_Position(0,0);
        sprintf(buf, "X:%2.0f",accel_ang_x);
        LCD_PrintString(buf);
        
        LCD_Position(0,8);
        sprintf(buf, "Y:%2.0f",accel_ang_y);;
        LCD_PrintString(buf);
        
        LCD_Position(1,canal*8);
        
        LCD_PrintString("V");
        LCD_PrintNumber(canal);
        LCD_PrintString(": ");
        LCD_PrintNumber(voltaje);*/
        
        LCD_Position(0,0);
        LCD_PrintString("Puntos: ");
        LCD_PrintNumber(puntuacion);
        canal=1-canal;
        LCD_Position(1,0);
        LCD_PrintNumber(balas_activas);
        LCD_PrintString("  ");
        
        voltaje++;
        
        switch((int) accel_ang_y){
            case 39 ... 90:
                jugador=15;
                if(canal==0){
                    if(col<voltaje){
                        col++;
                    }
                    else if(col>voltaje)
                        col--;
                }
                break;
            
            case 33 ... 38:
                jugador=14;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case 27 ... 32:
                jugador=13;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
            
            case 22 ... 26:
                jugador=12;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case 16 ... 21:
                jugador=11;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case 11 ... 15:
                jugador=10;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case 6 ... 10:
                jugador=9;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case 0 ... 5:
                jugador=8;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -6 ... -1:
                jugador=7;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -11 ... -7:
                jugador=6;
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -16 ... -12:
                jugador=5; 
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -22 ... -17:
                jugador=4; 
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -27 ... -23:
                jugador=3; 
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -33 ... -28:
                jugador=2; 
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            case -37 ... -34:
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
                
            default:
                jugador=0; 
                if(canal==0){
                    if(col<voltaje)
                        col++;
                    else if(col>voltaje)
                        col--;
                }
                break;
        }

        if(detectarColision(jugador,col,monstruo1) == 1) muerto=1;
        if(detectarColision(jugador,col,monstruo2) == 1) muerto=1;
        if(detectarColision(jugador,col,monstruo3) == 1) muerto=1;
        if(detectarColision(jugador,col,monstruo4) == 1) muerto=1;
        
        if(muerto == 1){
            PWM_Start();
            StripLights_MemClear(StripLights_BLACK);
            LCD_Position(0,0);
            LCD_PutChar(LCD_CUSTOM_0);LCD_PutChar(LCD_CUSTOM_0);LCD_PutChar(LCD_CUSTOM_0);
            LCD_PrintString("Game Over!");
            LCD_PutChar(LCD_CUSTOM_0);LCD_PutChar(LCD_CUSTOM_0);LCD_PutChar(LCD_CUSTOM_0);
            LCD_Position(1,0);
            LCD_PrintString("Puntos: ");
            LCD_PrintNumber(puntuacion);
            
            while(true){

                for(int i=0; i<8; i++){
                        StripLights_Pixel(i,i,StripLights_LTRED);
                        StripLights_Pixel(i,15-i,StripLights_LTRED);
                        StripLights_Pixel(15-i,i,StripLights_LTRED);
                        StripLights_Pixel(15-i,15-i,StripLights_LTRED);
                        StripLights_Trigger(1);
                        CyDelay(50);
                }
                CyDelay(500);
                StripLights_MemClear(StripLights_BLACK);
            }
        }

        if(canal==1 && balas_activas<16){
            int libre=0;
            while(balas[libre].disparada==1){
                libre++;   
            }
            if(voltaje == 2){
                if(vel_bala < 4){
                    vel_bala++;
                }
                else{
                    balas[libre].disparada =1;
                    balas[libre].posx = jugador;
                    balas[libre].posy = col + 1;
                    balas_activas++;
                    vel_bala=0;
                }
            }
            if(voltaje == 3){
                if(vel_bala < 3){
                    vel_bala++;
                }
                else{
                    balas[libre].disparada =1;
                    balas[libre].posx = jugador;
                    balas[libre].posy = col + 1;
                    balas_activas++;
                    vel_bala=0;
                }
            }
            if(voltaje == 4){
                if(vel_bala < 2){
                    vel_bala++;
                }
                else{
                    balas[libre].disparada =1;
                    balas[libre].posx = jugador;
                    balas[libre].posy = col + 1;
                    balas_activas++;
                    vel_bala=0;
                }
            }
            if(voltaje >= 5){
                    balas[libre].disparada =1;
                    balas[libre].posx = jugador;
                    balas[libre].posy = col + 1;
                    balas_activas++;
                    vel_bala=0;
                
            }
                       
        }
        
        for(int i=0; i<16; i++){
            if(balas[i].disparada==1){
                if(detectarColision(balas[i].posx,balas[i].posy,monstruo1) == 1){ 
                    monstruo1.muerto=1;
                    PWM_Start();
                    CyDelay(10);
                    PWM_Stop();
                    if(monstruo1.tipo==1)
                        puntuacion+=50;
                    else if(monstruo1.tipo==2)
                        puntuacion+=100;
                    else 
                        puntuacion+=200;
                }
                if(detectarColision(balas[i].posx,balas[i].posy,monstruo2) == 1){ 
                    monstruo2.muerto=1;
                    PWM_Start();
                    CyDelay(10);
                    PWM_Stop();
                    if(monstruo2.tipo==1)
                        puntuacion+=50;
                    else if(monstruo2.tipo==2)
                        puntuacion+=100;
                    else 
                        puntuacion+=200;
                }
                if(detectarColision(balas[i].posx,balas[i].posy,monstruo3) == 1){ 
                    monstruo3.muerto=1;
                    PWM_Start();
                    CyDelay(10);
                    PWM_Stop();
                    if(monstruo3.tipo==1)
                        puntuacion+=50;
                    else if(monstruo3.tipo==2)
                        puntuacion+=100;
                    else 
                        puntuacion+=200;
                }
                if(detectarColision(balas[i].posx,balas[i].posy,monstruo4) == 1){ 
                    monstruo4.muerto=1;
                    PWM_Start();
                    CyDelay(10);
                    PWM_Stop();
                    if(monstruo4.tipo==1)
                        puntuacion+=50;
                    else if(monstruo4.tipo==2)
                        puntuacion+=100;
                    else 
                        puntuacion+=200;
                }
            }
        }
       
        StripLights_MemClear(StripLights_BLACK);
        imprimirJugador();
        imprimirBalas();
        imprimirMonstruo(monstruo1);
        imprimirMonstruo(monstruo2);
        imprimirMonstruo(monstruo3);
        imprimirMonstruo(monstruo4);
        StripLights_Trigger(1);
        
        movimiento(&monstruo1);
        movimiento(&monstruo2);
        movimiento(&monstruo3);
        movimiento(&monstruo4);
        moverBalas();
         
        if(puntuacion>3000){
            monstruo1.velocidad =0;
            monstruo2.velocidad =0;
            monstruo3.velocidad =0;
            monstruo4.velocidad =0;
        }
        else if(puntuacion > 2000){
            monstruo1.velocidad =1;
            monstruo2.velocidad =3;
            monstruo3.velocidad =2;
            monstruo4.velocidad =1;
        }
        else if(puntuacion>1000){
            monstruo1.velocidad =2;
            monstruo2.velocidad =4;
            monstruo3.velocidad =3;
            monstruo4.velocidad =2;
        }
        CyDelay(50);
    }
}
